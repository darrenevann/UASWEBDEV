<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Input Data Peserta Skripsi</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css">
</head>

<body>
    <?php
    include("includes/config.php");

    // Simpan Data
    if (isset($_POST["Simpan"])) {
        $mhs_NPM = $_POST['mhs_NPM'];
        $peserta_SEMT = $_POST['peserta_SEMT'];
        $peserta_THAKD = $_POST['peserta_THAKD'];
        $peserta_TGLDAFTAR = $_POST['peserta_TGLDAFTAR'];
        $peserta_JUDUL = $_POST['peserta_JUDUL'];

        if (isset($_FILES['peserta_DOKUMEN']) && $_FILES['peserta_DOKUMEN']['name'] != "") {
            $peserta_DOKUMEN = $_FILES['peserta_DOKUMEN']['name'];
            $tmp = $_FILES['peserta_DOKUMEN']['tmp_name'];

            move_uploaded_file($tmp, 'dokumen/' . $peserta_DOKUMEN);

        } else {
            $peserta_DOKUMEN = "";
        }
        mysqli_query($conn, "INSERT INTO peserta VALUES ('$mhs_NPM', '$peserta_SEMT', '$peserta_THAKD', '$peserta_TGLDAFTAR', '$peserta_JUDUL', '$peserta_DOKUMEN')");
        echo "<script>alert('Data berhasil disimpan');document.location='inputpeserta.php';</script>";
    }

    // Ambil data mahasiswa
    $datamhs = mysqli_query($conn, "SELECT * FROM mahasiswa");
    $query = mysqli_query($conn, "SELECT * FROM peserta");
    ?>

    <div class="container mt-5">
        <h2 class="mb-4">Input Data Peserta Skripsi</h2>
        <form method="POST" enctype="multipart/form-data">

            <div class="mb-3 row">
                <label for="mhs_NPM" class="col-sm-2 col-form-label">NPM Mahasiswa</label>
                <div class="col-sm-10">
                    <select class="form-control select2" id="mhs_NPM" name="mhs_NPM" required>
                        <option value="">-- Pilih NPM Mahasiswa --</option>
                        <?php while ($row = mysqli_fetch_array($datamhs)) { ?>
                            <option value="<?php echo $row['mhs_NPM']; ?>">
                                <?php echo $row['mhs_NPM']; ?> - <?php echo $row['mhs_Nama']; ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>
            </div>

            
            <div class="mb-3 row">
                <label for="peserta_SEMT" class="col-sm-2 col-form-label">Semester</label>
                <div class="col-sm-10">
                    <select class="form-control" id="peserta_SEMT" name="peserta_SEMT" required>
                        <option value="">-- Pilih Semester --</option>
                        <option value="Ganjil">Ganjil</option>
                        <option value="Genap">Genap</option>
                    </select>
                </div>
            </div>
            
            <div class="mb-3 row">
                <label for="peserta_THAKD" class="col-sm-2 col-form-label">Tahun Akademik</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="peserta_THAKD" name="peserta_THAKD"
                        placeholder="contoh: 2025-2026" required>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="peserta_TGLDAFTAR" class="col-sm-2 col-form-label">Tanggal Daftar</label>
                <div class="col-sm-10">
                    <input type="date" class="form-control" id="peserta_TGLDAFTAR" name="peserta_TGLDAFTAR" required>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="peserta_JUDUL" class="col-sm-2 col-form-label">Judul Skripsi</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="peserta_JUDUL" name="peserta_JUDUL" required>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="peserta_DOKUMEN" class="col-sm-2 col-form-label">Upload Gambar</label>
                <div class="col-sm-10">
                    <input type="file" class="form-control" id="peserta_DOKUMEN" name="peserta_DOKUMEN"
                        accept=".jpg,.jpeg,.png ">
                    <small class="text-muted">Format gambar: JPG, JPEG, PNG</small>
                </div>
            </div>

            <div class="mb-3 row">
                <div class="col-sm-2"></div>
                <div class="col-sm-10">
                    <input type="submit" name="Simpan" value="Simpan" class="btn btn-success">
                    <input type="reset" name="Batal" value="Batal" class="btn btn-danger">
                </div>
            </div>
        </form>

        <hr class="mt-4 mb-4">

        <h3>Daftar Peserta Skripsi</h3>
        <table class="table table-bordered table-striped table-hover mt-3">
            <tr class="table-success">
                <th>NPM</th>
                <th>Semester</th>
                <th>Tahun Akademik</th>
                <th>Tanggal Daftar</th>
                <th>Judul</th>
                <th>Gambar</th>
            </tr>
            <?php while ($row = mysqli_fetch_array($query)) { ?>
                <tr>
                    <td><?php echo $row['mhs_NPM']; ?></td>
                    <td><?php echo $row['peserta_SEMT']; ?></td>
                    <td><?php echo $row['peserta_THAKD']; ?></td>
                    <td><?php echo $row['peserta_TGLDAFTAR']; ?></td>
                    <td><?php echo $row['peserta_JUDUL']; ?></td>
                    <td>
                        <?php if ($row['peserta_DOKUMEN'] == "") {
                            echo "<img src='images/UNTAR.jpg' width='400' height='300'/>";
                        } else { ?>
                            <img src="images/<?php echo $row['peserta_DOKUMEN']; ?>" width="400" height="300" class="img-responsive" />
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </table>
    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>

</body>

</html>