<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Mahasiswa</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
    <?php
    include("includes/config.php");

    if (isset($_POST['Simpan'])) {
        $mhs_NPM = $_POST['npmMHS'];
        $mhs_Nama = $_POST['namaMHS'];
        $mhs_Alamat = $_POST['alamatMHS'];
        $mhs_DOB = $_POST['lahirMHS'];
        $mhs_Ket = $_POST['ketMHS'];

        if (!empty($mhs_NPM)) {
            mysqli_query($conn, "INSERT INTO mahasiswa VALUES('$mhs_NPM', '$mhs_Nama', '$mhs_Alamat', '$mhs_DOB', '$mhs_Ket')");
            header("Location: inputmhs.php");
            exit;
        } else {
            echo "<h1>Maaf anda salah input</h1>";
            die("Anda harus mengisi NPM");
        }
    }

    $query = mysqli_query($conn, "SELECT * FROM mahasiswa");
    ?>

    <div class="row">
        <div class="col-1"></div>
        <div class="col-10">

            <form method="post">
                <div class="row mb-3">
                    <label for="npmMHS" class="col-sm-2 col-form-label">NPM Mahasiswa</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="npmMHS" name="npmMHS"
                            placeholder="Nomor Pokok Mahasiswa" maxlength="9" required>
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="namaMHS" class="col-sm-2 col-form-label">Nama Mahasiswa</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="namaMHS" name="namaMHS"
                            placeholder="Isikan Nama Mahasiswa">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="alamatMHS" class="col-sm-2 col-form-label">Alamat Mahasiswa</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="alamatMHS" name="alamatMHS"
                            placeholder="Isikan Alamat Mahasiswa">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="lahirMHS" class="col-sm-2 col-form-label">Tanggal Lahir</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="lahirMHS" name="lahirMHS" placeholder="YYYY/MM/DD">
                    </div>
                </div>

                <div class="row mb-3">
                    <label for="ketMHS" class="col-sm-2 col-form-label">Keterangan</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="ketMHS" name="ketMHS"
                            placeholder="Isikan Keterangan Mahasiswa">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-2"></div>
                    <div class="col-10">
                        <input type="submit" class="btn btn-success" value="Simpan" name="Simpan">
                        <input type="reset" class="btn btn-danger" value="Batal" name="Batal">
                    </div>
                </div>
            </form>
            <div class="1"></div>
        </div>
    </div>
    <div class="row">
        <div class="col-1"></div>
        <div class="col-10">
            <div class="jumbotron mt-5 mb-3">
                <h1 class="display-5">Daftar Mahasiswa</h1>
            </div>

            <table class="table table-success table-striped mt-4">
                <tr class="info">
                    <th>NPM</th>
                    <th>Nama Mahasiswa</th>
                    <th>Alamat Mahasiswa</th>
                    <th>Tanggal Lahir</th>
                    <th>Keterangan</th>
                </tr>

                <?php { ?>
                    <?php while ($row = mysqli_fetch_array($query)) { ?>
                        <tr class="danger">
                            <td><?php echo $row['mhs_NPM']; ?></td>
                            <td><?php echo $row['mhs_Nama']; ?></td>
                            <td><?php echo $row['mhs_Alamat']; ?></td>
                            <td><?php echo $row['mhs_DOB']; ?></td>
                            <td><?php echo $row['mhs_Ket']; ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </table>
        </div>
    </div>
    </div>
    </div>
</body>

</html>