<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Dosen</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>

<body>
    <?php
    include("includes/config.php");

    if (isset($_POST['Simpan'])) {
        $dosen_NIDN = $_POST['dosen_NIDN'];
        $dosen_NIK = $_POST['dosen_NIK'];
        $dosen_Nama = $_POST['dosen_Nama'];
        $dosen_KET = $_POST['dosen_KET'];

        if (!empty($dosen_NIDN)) {
            mysqli_query($conn, "INSERT INTO dosen VALUES('$dosen_NIDN', '$dosen_NIK', '$dosen_Nama', '$dosen_KET')");
            header("Location: inputdosen.php");
            exit;
        } else {
            echo "<h1>Maaf anda salah input</h1>";
            die("Anda harus mengisi NIDN");
        }
    }


    $query = mysqli_query($conn, "SELECT * FROM dosen");
    ?>

    <div class="row">
        <div class="col-1"></div>
        <div class="col-10">

            <form method="post">
                <div class="row mb-3 mt-5">
                    <label for="dosen_NIDN" class="col-sm-2 col-form-label">NIDN dosen</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="dosen_NIDN" name="dosen_NIDN"
                            placeholder="NIDN dosen" maxlength="9" required>
                    </div>
                </div>

                <div class="row mb-3 mt-5">
                    <label for="dosen_NIK" class="col-sm-2 col-form-label">NIK dosen</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="dosen_NIK" name="dosen_NIK"
                            placeholder="NIK dosen">
                    </div>
                </div>

                <div class="row mb-3 mt-5">
                    <label for="dosen_Nama" class="col-sm-2 col-form-label">Nama dosen</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="dosen_Nama" name="dosen_Nama"
                            placeholder="Isikan Nama dosen">
                    </div>
                </div>

                <div class="row mb-3 mt-5">
                    <label for="dosen_KET" class="col-sm-2 col-form-label">Keterangan dosen</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="dosen_KET" name="dosen_KET"
                            placeholder="Isikan Keterangan">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-2"></div>
                    <div class="col-10">
                        <input type="submit" class="btn btn-success" value="Simpan" name="Simpan">
                        <input type="reset" class="btn btn-danger" value="Batal" name="Batal">
                    </div>
                </div>
            </form>
            <div class="1"></div>
        </div>
    </div>
    <div class="row">
        <div class="col-1"></div>
        <div class="col-10">
            <div class="jumbotron mt-5 mb-3">
                <h1 class="display-5">Daftar Dosen</h1>
            </div>

            <table class="table table-success table-striped mt-4">
                <tr class="info">
                    <th>NIDN Dosen</th>
                    <th>NIK Dosen</th>
                    <th>Nama Dosen</th>
                    <th>Keterangan Dosen</th>
                </tr>

                <?php { ?>
                    <?php while ($row = mysqli_fetch_array($query)) { ?>
                        <tr class="danger">
                            <td><?php echo $row['dosen_NIDN']; ?></td>
                            <td><?php echo $row['dosen_NIK']; ?></td>
                            <td><?php echo $row['dosen_NAMA']; ?></td>
                            <td><?php echo $row['dosen_KET']; ?></td>
                        </tr>
                    <?php } ?>
                <?php } ?>
            </table>
        </div>
    </div>
    </div>
    </div>
</body>

</html>