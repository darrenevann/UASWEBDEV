<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/css/select2.min.css">
</head>
<body>
<?php
include("includes/config.php");
  if(isset($_POST['Simpan']))
  {
    $mhs_NPM = $_POST['npmMHS'];
    $dosen_NIDN = $_POST['nidnDOSEN'];
    $penasihat_FILE = $_FILES['penasihatFILE']['name'];
    $dokumen_tmp = $_FILES['penasihatFILE']['tmp_name'];
    move_uploaded_file($dokumen_tmp,'images/' .$penasihat_FILE);
    $penasihat_KET = $_POST['penasihatKET'];
    mysqli_query($conn, "insert into Penasihat values('$mhs_NPM', '$dosen_NIDN', '$penasihat_FILE', '$penasihat_KET')");
    header("location:inputpenasihat.php");
  }
  $query = mysqli_query($conn, "select * from penasihat");
  $datamhs = mysqli_query($conn, "select * from mahasiswa")
?>
  <div class="row">
  <div class="col-1"></div>
  <div class="col-10">
  <form method="POST" enctype ="multipart/form-data">
    <form>
      <div class="row mb-3 mt-5">
        <br>
            <div class="row mb-3">
                <label for="npmMHS" class="col-sm-2 col-form-label">NPM MAHASISWA</label>
                <div class="col-sm-10">
                    <select class= "form-control" id="npmMHS" name="npmMHS">
                        <option>Cari NPM Mahasiswa</option>
                        <?php while($row = mysqli_fetch_array($datamhs))
                        { ?>
                            <option value="<?php echo $row["mhs_NPM"]?>">
                                <?php echo $row["mhs_NPM"]?>
                                <?php echo $row["mhs_Nama"]?>
                            </option> 
                        <?php } ?>
                    </select>  
                </div>
            </div>
            <div class="row mb-3">
                <label for="nidnDOSEN" class="col-sm-2 col-form-label">NIDN DOSEN</label>
                <div class="col-sm-10">
                    <input type="text" class="form-control" id="nidnDOSEN" name="nidnDOSEN" placeholder="NOMOR INDUK DOSEN" required=" ">
                </div>
            </div>
            <div class="row mb-3">
            <label for="penasihatFILE" class="col-sm-2 col-form-label">FILE Penasihat</label>
            <div class="col-sm-10">
                <input type="file" class="form-control" id="penasihatFILE" name="penasihatFILE" placeholder="isikan FILE Penasihat">
                <p class="help-block">Unggah File Dokumen</p>
            </div>
        </div>
        <div class="row mb-3">
            <label for="penasihatKET" class="col-sm-2 col-form-label">Keterangan penasihat</label>
            <div class="col-sm-10">
                <input type="text" class="form-control" id="penasihatKET" name="penasihatKET" placeholder="isikan keterangan penasihat">
            </div>
        </div>
      <div class="form-group row">
        <div class="col-2"></div>
          <div class="col-10">
            <input type="submit" class="btn btn-success" value="Simpan" name="Simpan">
            <input type="reset" class="btn btn-danger" value="Batal" name="Batal">
          </div>
        </div>
    </form> <br><br>
    <div class="row">
<div class="col-1"></div>
<div class="col-10">
  <div class="jumbotron mt-5 mb-3">
    <h1 class="display-5"> Daftar Penasihat</h1>
    </div>
  
    <table class="table table-dark table-striped table-hover">
      <tr class="info">
  <table class="table table-dark table-striped">
    <tr class="info">
      <th>NPM Mahasiswa</th>
      <th>NIDN Dosen</th>
      <th>Penasihat FILE</th>
      <th>Keterangan</th>
    </tr>
    <?php { ?>
    <?php while ($row = mysqli_fetch_array($query))
    { ?>   
      <tr class="danger">
        <td><?php echo $row['mhs_NPM']; ?> </td> 
        <td><?php echo $row['dosen_NIDN']; ?> </td> 
        <td>
            <?php if ($row['penasihat_FILE']==""){echo "<img src= 'images/KAWAII.jpg' width='88'/>";}else{?>
            <img src="images/<?php echo $row['penasihat_FILE'] ?>" width="88" class="img-responsive" />
            <?php }?>
        <td><?php echo $row['penasihat_KET']; ?> </td>  
      </tr>
    <?php } ?>
  <?php } ?>
  </table>
  </div>
  </div>
    <div class="1"></div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.9/js/select2.min.js"></script>
</body>

</html>